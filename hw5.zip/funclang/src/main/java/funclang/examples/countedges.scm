(define countedges
  (lambda (node graph)
    (if (null? graph)
      0
      (+ (if (= node (car (car graph))) 1 0)
        (if (= node (cdr (car graph))) 1 0)
        (countedges node (cdr graph))))))