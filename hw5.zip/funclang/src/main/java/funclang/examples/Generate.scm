(define Generate
  (lambda (x f z)
    (if (= z 0)
      (list)
      (if (< z 0)
        (list)
        (cons (list x (f x))
          (Generate (+ x 1) f (- z 1)))))))