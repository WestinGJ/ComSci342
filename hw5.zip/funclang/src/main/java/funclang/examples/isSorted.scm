(define isSortedHelper
  (lambda (lst dir)
    (if (null? lst)
      #t
      (if (null? (cdr lst))
        #t
        (if (= (car lst) (car (cdr lst)))
          (isSortedHelper (cdr lst) dir)
          (if (= dir 0)
            (if (< (car lst) (car (cdr lst)))
              (isSortedHelper (cdr lst) 1)
              (isSortedHelper (cdr lst) -1))
            (if (= dir 1)
              (if (< (car lst) (car (cdr lst)))
                (isSortedHelper (cdr lst) 1)
                #f)
              (if (> (car lst) (car (cdr lst)))
                (isSortedHelper (cdr lst) -1)
                #f))))))))

(define isSorted
  (lambda (lst)
    (isSortedHelper lst 0)))
