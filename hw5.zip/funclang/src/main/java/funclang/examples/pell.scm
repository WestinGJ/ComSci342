(define nextPell
  (lambda (p0 p1)
    (+ (* 2.0 p1) p0)))

(define pellLoop
  (lambda (rem p0 p1 accRev)
    (if (= rem 0)
      (reverse accRev)
      (pellLoop (- rem 1)
        p1
        (nextPell p0 p1)
        (cons (nextPell p0 p1) accRev)))))

(define pell
  (lambda (n)
    (if (= n 0)
      (list)
      (if (= n 1)
        (list 0.0)
        (pellLoop (- n 2) 0.0 1.0 (cons 1.0 (cons 0.0 (list))))))))
