(define reverse
        (lambda (lst)
          (if (null? lst)
            (list)
            (append (reverse (cdr lst)) (list (car lst))))))


