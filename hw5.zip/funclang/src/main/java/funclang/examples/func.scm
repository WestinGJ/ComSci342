(define func
  (lambda (x)
    (+ (- (* 2 (* x x)) x) 1)))