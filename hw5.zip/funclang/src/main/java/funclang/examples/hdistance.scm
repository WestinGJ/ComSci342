(define hdistanceHelper
  (lambda (a b)
    (if (null? a)
      (if (null? b)
        0
        -1)
      (if (null? b)
        -1
        (let ((rest (hdistanceHelper (cdr a) (cdr b))))
          (if (= rest -1)
            -1
            (+ (if (= (car a) (car b)) 0 1)
              rest)))))))

(define hdistance
  (lambda (a b)
    (hdistanceHelper a b)))