(define student_grades
  (list (cons 0 90) (cons 1 85) (cons 2 92)))

(define get_scores
  (lambda (pairs)
    (if (null? pairs)
      (list)
      (cons (cdr (car pairs))
        (get_scores (cdr pairs))))))

(define sameLength
  (lambda (a b)
    (if (null? a)
      (if (null? b)
        #t
        #f)
      (if (null? b)
        #f
        (sameLength (cdr a) (cdr b))))))

(define combineHelper
  (lambda (ids ages)
    (if (null? ids)
      (list)
      (cons (cons (car ids) (car ages))
        (combineHelper (cdr ids) (cdr ages))))))

(define combine
  (lambda (ids ages)
    (if (sameLength ids ages)
      (combineHelper ids ages)
      (list))))


