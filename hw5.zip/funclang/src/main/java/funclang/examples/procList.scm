(define sameLength
  (lambda (a b)
    (if (null? a)
      (if (null? b)
        #t
        #f)
      (if (null? b)
        #f
        (sameLength (cdr a) (cdr b))))))

(define procListHelper
  (lambda (op lst1 lst2)
    (if (null? lst1)
      (list)
      (cons (op (car lst1) (car lst2))
        (procListHelper op (cdr lst1) (cdr lst2))))))

(define procList
  (lambda (op lst1 lst2)
    (if (sameLength lst1 lst2)
      (procListHelper op lst1 lst2)
      (list))))

(define add
  (lambda (p q)
    (cons (+ (car p) (car q))
      (+ (cdr p) (cdr q)))))

