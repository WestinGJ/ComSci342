(define compList
  (lambda (lst)
    (if (null? lst)
      (list)
      (let ((rest (compList (cdr lst))))
        (if (null? rest)
          (list (car lst))
          (if (= (car lst) (car rest))
            rest
            (cons (car lst) rest)))))))