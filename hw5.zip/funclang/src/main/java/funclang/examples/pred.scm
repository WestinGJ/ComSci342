(define filter_list
  (lambda (pred lst)
    (if (null? lst)
      (list)
      (let ((x (car lst))
             (rest (filter_list pred (cdr lst))))
        (if (pred x)
          (cons x rest)
          rest)))))
