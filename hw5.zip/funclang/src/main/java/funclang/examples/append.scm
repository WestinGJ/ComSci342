(define append
        (lambda (a b)
          (if (null? a) b (cons (car a) (append (cdr a) b))
            )
          )
  )